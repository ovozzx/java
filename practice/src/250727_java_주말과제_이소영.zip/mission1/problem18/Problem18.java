package mission1.problem18;

public class Problem18 {

	
	public static void main(String[] args) {
		
		
		for(int i = 0 ; i < 5 ; i++) {
			System.out.println("안녕하세요?");
		}

	
	}

}
