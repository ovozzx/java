package mission1.problem6;


public class Problem6 {

	public static void main(String[] args) {
		
		int numberOne = 1;
		int numberTwo = 2;
		
		System.out.println("첫번째 변수 : %d" .formatted(numberOne));
		System.out.println("첫번째 변수 : %d" .formatted(numberTwo));
	}
}