package mission1.problem11;

public class Problem11 {
	
	public static void main(String[] args) {
		
		int numberOne = 4;
		int numberTwo = 3;
		
		double result = (double) numberOne / numberTwo;
		
		System.out.println("나누기 결과 : %f" .formatted(result));
		
		
	}

}
