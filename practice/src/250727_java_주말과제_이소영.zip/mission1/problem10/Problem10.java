package mission1.problem10;

public class Problem10 {

	public static void main(String[] args) {
		
		int numberOne = 4;
		int numberTwo = 3;
		
		int rest = numberOne % numberTwo;
		
		System.out.println("나누기 나머지 : %d" .formatted(rest));
		
		
	}
	
	
}