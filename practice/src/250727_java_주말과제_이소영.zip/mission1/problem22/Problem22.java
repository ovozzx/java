package mission1.problem22;

public class Problem22 {

	public static void main(String[] args) {
		
		for(int i = 1 ; i <= 50 ; i++) {
			
			if(i >= 30 && i < 40) {
				System.out.println(i);
			}
			
		}
	}
	
}
