package mission1.problem8;

public class Problem8 {

	public static void main(String[] args) {
		
		int numberOne = 1;
		int numberTwo = 2;
		
		int mul = numberOne * numberTwo;
		
		System.out.println("곱하기 결과 : %d" .formatted(mul));
		
		
	}
	
}