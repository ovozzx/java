package mission1.problem7;

public class Problem7 {
	
	public static void main(String[] args) {
		
		int numberOne = 1;
		int numberTwo = 2;
		int numberThree = 3;
		int numberFour = 4;
		
		int sum = numberOne + numberTwo + numberThree + numberFour;
		
		System.out.println("합계 : %d" .formatted(sum));
		
		
	}
	
}