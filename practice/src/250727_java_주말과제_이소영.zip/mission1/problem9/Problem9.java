package mission1.problem9;


public class Problem9 {

	public static void main(String[] args) {
		
		int numberOne = 4;
		int numberTwo = 2;
		
		int div = numberOne / numberTwo;
		
		System.out.println("나누기 몫 : %d" .formatted(div));
		
		
	}
	
	
}